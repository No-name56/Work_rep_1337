#include <stdio.h>
#include "ssd1306_fonts.h"
#include "ssd1306.h"
#include "ssd1306_conf.h"
#include <math.h>
#include "game_of_life.h"

int field[128][64] = {0};
int player1_score = 0, player2_score = 0;

void InitField(float voltage1, float voltage2) {
	ClearField();

	for (int i = 0; i < 128; i++) {
		field[i][17] = 2;
		field[i][18] = 2;
		field[i][19] = 2;

		field[i][63] = 2;
		field[i][62] = 2;
		field[i][61] = 2;
	}

	InitPlatform1(voltage1);
	InitPlatform2(voltage2);
}

void ClearField(void) {
	for (int j = 0; j < 128; j++) {
		for (int k = 17; k < 64; k++) {
			field[j][k] = 0;
		}
	}
}

void ShowField(void) {
	for (int j = 0; j < 128; j++) {
		for (int k = 17; k < 64; k++) {
			if (field[j][k]) {
				ssd1306_DrawPixel(j, k, White);
			} else {
				ssd1306_DrawPixel(j, k, Black);
			}

		}
	}

	ssd1306_UpdateScreen();
}

void InitPlatform1(float voltage1) {
	int begin = (int)voltage1/158 + 19;
	for (int i = begin; i < begin + 15; i++) {
		field[5][i] = 2;
		field[6][i] = 2;
		field[7][i] = 2;
		field[8][i] = 2;
	}
}

void InitPlatform2(float voltage2) {
	int begin = (int)voltage2/158 + 19;
	for (int i = begin; i < begin + 15; i++) {
		field[122][i] = 2;
		field[121][i] = 2;
		field[120][i] = 2;
		field[119][i] = 2;
	}
}

typedef struct TBall {
	float x;
	float y;
	int xi;
	int yi;
	float speed;
	float alpha;
} Tball;

Tball ball;

void InitBall(void) {
	MoveBall(63, 38);
	ball.alpha = 1;
	ball.speed = 6;
}

void PutBall(int value) {
	field[ball.xi-2][ball.yi-2] = value;
	field[ball.xi-2][ball.yi-1] = value;
	field[ball.xi-2][ball.yi] = value;
	field[ball.xi-2][ball.yi+1] = value;
	field[ball.xi-2][ball.yi+2] = value;

	field[ball.xi-1][ball.yi-2] = value;
	field[ball.xi-1][ball.yi-1] = value;
	field[ball.xi-1][ball.yi] = value;
	field[ball.xi-1][ball.yi+1] = value;
	field[ball.xi-1][ball.yi+2] = value;

	field[ball.xi][ball.yi-2] = value;
	field[ball.xi][ball.yi-1] = value;
	field[ball.xi][ball.yi] = value;
	field[ball.xi][ball.yi+1] = value;
	field[ball.xi][ball.yi+2] = value;

	field[ball.xi+1][ball.yi-2] = value;
	field[ball.xi+1][ball.yi-1] = value;
	field[ball.xi+1][ball.yi] = value;
	field[ball.xi+1][ball.yi+1] = value;
	field[ball.xi+1][ball.yi+2] = value;

	field[ball.xi+2][ball.yi-2] = value;
	field[ball.xi+2][ball.yi-1] = value;
	field[ball.xi+2][ball.yi] = value;
	field[ball.xi+2][ball.yi+1] = value;
	field[ball.xi+2][ball.yi+2] = value;
}

void MoveBall(float x, float y) {
	ball.x = x;
	ball.y = y;
	ball.xi = (int)round(ball.x);
	ball.yi = (int)round(ball.y);
}

void AutoMoveBall(void) {
	if (ball.xi <= 3) {
		player2_score++;
		MoveBall(63, 38);
		ball.alpha += M_PI/2;
	} else if (ball.xi >= 123) {
		player1_score++;
		MoveBall(63, 38);
		ball.alpha += M_PI/2;
	}

	if (player1_score == 3) {
		player1_score = 0;
		player2_score = 0;
		ssd1306_Fill(Black);
		ssd1306_SetCursor(22, 27);
		ssd1306_WriteString("Player 1 won", Font_7x10, White);
		ssd1306_UpdateScreen();
		HAL_Delay(5000);
	} else if (player2_score == 3) {
		player1_score = 0;
		player2_score = 0;
		ssd1306_Fill(Black);
		ssd1306_SetCursor(22, 27);
		ssd1306_WriteString("Player 2 won", Font_7x10, White);
		ssd1306_UpdateScreen();
		HAL_Delay(5000);
	}

	if (ball.alpha < 0) {
		ball.alpha += M_PI * 2;
	} else if (ball.alpha > M_PI * 2) {
		ball.alpha -= M_PI * 2;
	}

	Tball bl = ball;

	PutBall(0);

	float voltage1 = 500;
	float voltage2 = 3000;

	InitField(voltage1, voltage2);
	MoveBall(cos(ball.alpha) * ball.speed + ball.x, sin(ball.alpha) * ball.speed + ball.y);

	if (field[ball.xi][ball.yi] == 2) {
		if ((ball.yi != bl.yi) && (ball.xi != bl.xi)) {
			if (field[ball.xi][bl.yi] == field[bl.xi][ball.yi] && field[ball.xi][bl.yi] == 2) {
				bl.alpha = bl.alpha + M_PI;
			} else {
				if (field[ball.xi][bl.yi] == 2) {
					bl.alpha = (2 * M_PI - bl.alpha) + M_PI;
				} else {
					bl.alpha = 2 * M_PI - bl.alpha;
				}
			}
		} else if (ball.yi == bl.yi) {
			bl.alpha = M_PI * 3 - bl.alpha;
		} else {
			bl.alpha = 2 * M_PI - bl.alpha;
		}

		ball = bl;

	}

	PutBall(1);

	ShowField();
	counter();
	AutoMoveBall();
}

void counter(void) {
	char str1[10];
	char str2[10];

	sprintf(str1, "%d", player1_score);
	ssd1306_SetCursor(42, 0);
	ssd1306_WriteString(str1, Font_7x10, White);
	ssd1306_SetCursor(0, 0);
	ssd1306_WriteString("Pl.1:", Font_7x10, White);

	sprintf(str2, "%d", player2_score);
	ssd1306_SetCursor(72, 0);
	ssd1306_WriteString("Pl.2:", Font_7x10, White);
	ssd1306_SetCursor(114, 0);
	ssd1306_WriteString(str2, Font_7x10, White);

	hor_line(15);
	ssd1306_UpdateScreen();
}

void hor_line(int row) {
	for (int i = 0; i < 128; i++) {
		ssd1306_DrawPixel(i, row, Black);
	}
}

void fill_screen(void) {
	ssd1306_Fill(White);
	ssd1306_UpdateScreen();
	HAL_Delay(2000);
}

void clear_screen(void) {
	HAL_Delay(2000);
	ssd1306_Fill(Black);
	ssd1306_UpdateScreen();
}
