#ifndef SRC_GAME_OF_LIFE_H_
#define SRC_GAME_OF_LIFE_H_

void LCDInit(void);

void fill_screen(void);
void clear_screen(void);
void counter(void);
void hor_line (int row);

void InitField(float voltage1, float voltage2);
void ClearField(void);
void ShowField(void);

struct TBall;

void InitBall(void);
void PutBall(int value);
void MoveBall(float x, float y);
void AutoMoveBall(void);

void InitPlatform1(float voltage1);
void InitPlatform2(float voltage2);

#endif /* SRC_GAME_OF_LIFE_H_ */
